[
  {
    "pantun": "Ini adalah pantun 1"
  },
  {
    "pantun": "Ini adalah pantun 2"
  }
]
